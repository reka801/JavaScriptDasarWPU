// var s = '';
// for( var i = 0; i < 5; i++) {
	// for( var j = 0; j < 10; j++) {
		// s += '*'
	// }
	// s +='\n';
// }
// console.log(s);

// cara sendiri
// var s = '';
// for( var i = 0; i < 10; i++) {
	// for( var j = i; j < 10; j++) {
		// s += '*'
	// }
	// s +='\n';
// }
// console.log(s);

// cara pak dika
var s = '';
for( var i = 10; i > 0; i--) {
	for( var j = 0; j < i; j++) {
		s += '*'
	}
	s +='\n';
}
console.log(s);
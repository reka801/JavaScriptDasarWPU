var i = 10;
var operasi = 6;
var no = 1;

for(no; no <= i; no++) {
	if(no <= operasi) {
		console.log('Angkot ' + no + ' Sedang beroperasi');
	}
	else {
		console.log('Angkot ' + no + ' Sedang tidak beroperasi');
	}
}
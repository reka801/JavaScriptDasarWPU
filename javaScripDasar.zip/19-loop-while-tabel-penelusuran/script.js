var jmlAngkot = 10;
var i = 1;
while(i <= jmlAngkot ) {
	console.log('Angkot No. ' + i + ' Beroperasi dengan baik.');
i++;
}
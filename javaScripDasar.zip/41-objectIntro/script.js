// membuat object
var siswa = {
    nama: 'Syafiq Fajrian Emha',
    umur: 16,
    jurusan: 'Rekayasa Perangkat Lunak',
    nilai: [60, 70, 80],
    alamat: {
        jalan: 'Jln. Soekarno Hatta',
        provinsi: 'Jawa Tengah',
        kota: 'Purbalingga'
    }
};
var angka = prompt('Masukkan akngka');
if (angka % 2 == 0 ) {
	alert(angka + ' Adalah bilangan GENAP');
} else if ( angka % 2 == 1 ) {
	alert(angka + ' Adalah bilangan GANJIL');
} else {
	alert('Yang anda input bukan angka!');
}
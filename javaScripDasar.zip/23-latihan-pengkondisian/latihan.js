var i = 10;
var operasi = 6;
var no = 1;

for(no; no <= i; no++) {
	if(no <= operasi && no !== 5) {
		console.log('Angkot ' + no + ' Sedang beroperasi');
	}
	else if(no == 5 || no == 8 || no == 10) {
		console.log('Angkot ' + no + ' Sedang lembur')
	}
	else {
		console.log('Angkot ' + no + ' Sedang tidak beroperasi');
	}
}

// var i = 10;
// var operasi = 6;
// var no = 1;

// for(no; no <= i; no++) {
// 	if(no <= operasi) {
// 		console.log('Angkot ' + no + ' Sedang beroperasi');
// 	}
// 	else if(no == 8 || no == 10) {
// 		console.log('Angkot ' + no + ' Sedang lembur')
// 	}
// 	else {
// 		console.log('Angkot ' + no + ' Sedang tidak beroperasi');
// 	}
// }


// var i = 10;
// var operasi = 6;
// var no = 1;

// for(no; no <= i; no++) {
// 	if(no <= operasi ) {
// 		console.log('Angkot ' + no + ' Sedang beroperasi');
// 	}
// 	else if(no == 8 ) {
// 		console.log('Angkot ' + no + ' Sedang lembur')
// 	}
// 	else {
// 		console.log('Angkot ' + no + ' Sedang tidak beroperasi');
// 	}
// }
var makanan = prompt('Masukkan nama makanan : \n (cth: nasi, daging, hamburger');
var minuman = prompt('Masukkan nama minuman: \n cth: softdrink, susu, jus')

switch ( makanan ) {
	case 'nasi' :
		alert('Anda memilih nasi');
		break;
	case 'daging' :
		alert('Anda memilih daging');
		break;
	case 'hamburger' :
		alert('Anda memilih hamburger');
		break;
	default :
		alert('anda salah memilih');
		break;
}

switch ( minuman ) {
	case 'softdrink' :
		alert('Anda memilih softdrink');
		break;
	case 'susu' :
		alert("anda memilih susu")
   		break;
	case 'jus' :
		alert('Anda memilih jus');
		break;
	default :
		alert('anda salah memilih');
		break;
}
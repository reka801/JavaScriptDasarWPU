var angka = prompt('Masukkan angka 1-3');

switch ( angka ) {
	case '1' :
		alert('Anda memasukkan angka 1');
		break;
	case '2' :
		alert('Anda memasukkan angka 2');
		break;
	case '3' :
		alert('Anda memasukkan angka 3');
		break;
	default :
		alert('Angka yang anda masukkan salah');
		break;
}
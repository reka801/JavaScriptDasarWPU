//"use strict" untuk menjadikan semuanya menjadi variabel lokal dan tidak mengotori global

// global scope / window scope
// var a = 1;

// function tes (){
// 	// name conflict
// 	var a = 2;
// 	console.log(a);
// 	console.log(window.a);
// }

// tes();
// console.log(a);

var a = 1;

function tes (a) {
	console.log(a);
}

tes(2);
console.log(a);






// dalam funtion kita dapat memanggil variabel global , sedangkan jika di luar function kita tidak dapat memanggil variabel yang ada di dalam function
function jumlahVolumeDuaKubus(a,b) {

	return  a * a * a + b * b * b;
}


alert(jumlahVolumeDuaKubus(8,3));

//reafactoring adalah penyederhanaan sebuah program dan mengefisienkan nya
// 4. Splice
// splice (indexAwal, mauDihapusBerapa, elemenBaru, elemenBaru2, ....)
// var arr = ['Syafiq', 'Fajrian', 'Emha'];
// arr.splice(2, 0, 'Diki');
// console.log(arr.join(' - '));

// 5. Slice
// slice (awal, akhir);
var arr = ['Syafiq', 'Fajrian', 'Emha', 'Diki', 'Deva'];
var arr2 = arr.slice(0, 3);
console.log(arr2.join(' - '));
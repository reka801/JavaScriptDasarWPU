var i = 0;
var kesempatan = 3;
for(i = kesempatan; i > 0 ; i--){
	// pilihan player
	alert('Kesempatanmu memilih adalah ' + i + 'Kali');
	var p = prompt('Pilih angka 1-10');
	var j = i -1;
	// pilihan computer
	// bilangan random
	var com =Math.floor(Math.random() * 10 + 1);

	if( com >= 0.00 && com <= 0.10) {
		com = '1';
	} else if ( com >= 0.11 && com <= 0.20) {
		com = '2';
	} else if ( com >= 0.21 && com <= 0.30) {
		com = '3';
	} else if ( com >= 0.31 && com <= 0.40) {
		com = '4';
	} else if ( com >= 0.41 && com <= 0.50) {
		com = '5';
	} else if ( com >= 0.51 && com <= 0.60) {
		com = '6';
	} else if ( com >= 0.61 && com <= 0.70) {
		com = '7';
	} else if ( com >= 0.71 && com <= 0.80) {
		com = '8';
	} else if ( com >= 0.81 && com <= 0.90) {
		com = '9';
	} else if ( com >= 0.91 && com <= 1) {
		com = '10';
	} else {
		alert('Yang anda masukkan salah');
	}

	// rules
	var hasil = '';

	if ( p == com ) {
		hasil = 'BENAR!'
	} else if(p < com) {
		hasil = (p < com) ? 'RENDAH' : 'TINGGI';
	} else if ( p > com ) {
		hasil = (p > com ) ? 'TINGGI' : 'RENDAH';
	}

	// tampilkan hasil

	if (p == com ) {
		alert( hasil + '! angka yang di cari adalah ' + p );
		break;
	} else {
		alert('Pilihan anda terlalu ' + hasil + '\nAnda masih memiliki kesempatan ' + j + 'kali');
	}
	
	
}
alert('Hasil yang dicari adalah ' + com);

alert('Terimakasih sudah bermain');
var tanya = true;
while( tanya ){
	// pilihan player
	var p = prompt('Pilih : gajah, semut, orang');
	// pilihan computer
	// bilangan random
	var com = Math.random();

	if( com <0.34) {
		com = 'gajah';
	} else if ( com >= 0.34 && com < 0.67) {
		com = 'orang';
	} else {
		com = 'semut';
	}
	// rules
	var hasil = '';

	if ( p == com ) {
		hasil = 'SERI!'
	} else if (p == 'gajah'){
		// baris 26 shortcutnya
		// if(com == 'orang' ) {
			// hasil == 'MENANG!';
		// } else {
			// hasil = 'KALAH!';
		// }
		hasil = ( com == 'orang') ? 'MENANG!' : 'KALAH!';
	} else if ( p == 'orang') {
		hasil = ( com == 'gajah') ? 'KALAH!' : 'MENANG!';
	} else if ( p == 'semut') {
		hasil = ( com == 'gajah') ? 'MENANG!' : 'KALAH!'
	} else {
		hasil = 'MEmasukkan pilihan SALAH!'
	}

	// tampilkan hasil
	alert('Kamu memilih :' + p + ' dan komputer memilih : ' + com + '\nMaka hasilnya : Kamu ' + hasil);

	tanya = confirm('lagi?');
}

alert('Terimakasih sudah bermain');
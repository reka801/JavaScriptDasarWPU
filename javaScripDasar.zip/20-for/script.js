// Trace Tabl e Logic
var i = 10;
var operasi = 6;
var no = 1;
while(no <= operasi){
	console.log('Agnkot No. ' + no + ' berjalan dengan baik');
no++;
}

for(operasi = no ; no <=i; no++) {
	console.log('Angkot No. ' + no + ' tidak beroperasi')

}


// hasil pak dhika 
// var i = 10;
// var operasi = 6;
// var no = 1;
// while(no <= operasi){
	// console.log('Agnkot No. ' + no + ' berjalan dengan baik');
// no++;
// }

// for(no = operasi + 1 ; no <=i; no++) {
	// console.log('Angkot No. ' + no + ' tidak beroperasi')

// }
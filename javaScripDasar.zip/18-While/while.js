// var ulang = true;
// while(ulang) {
	// console.log('Hello World');
	// ulang = confirm('lagi?');
// }

// var i = 1;
// while(i <= 5){
	// console.log('Heloo World');
// i++;	
// }


// var i = 1;
// while(i <= 10){
	 // console.log('Hello World ' + i + 'x');
	 // i++;
// }

var i = 1;
while(i <= 10){
	 console.log('Angkot No. ' + i + ' Beroperasi dengan baik.');
i++;
}
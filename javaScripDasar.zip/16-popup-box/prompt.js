var nama = prompt('masukkan nama:'),
	halo = ('Halo');
alert(halo + ' ' + nama);
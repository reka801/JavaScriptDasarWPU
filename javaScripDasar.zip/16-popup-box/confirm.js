var tes = confirm('kamu yakin?');
if (tes === true) {
	alert('user menekan Ok');
}
else {
	alert('user menekan CANCEL');
}
// mengembalikan nilai boolean
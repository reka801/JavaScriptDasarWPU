alert('Selamat datang..');
var lagi = true;

while ( lagi ) {
	var nama = prompt('masukkan nama');
	alert('halo ' + nama);

	lagi =  confirm('coba lagi?');
}

alert('Terima kasih..');
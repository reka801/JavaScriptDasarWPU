// alert('mulai');
// for (var i = 0; i < 5; i++) {
//     alert('Hello World! ' + i);
// }
// alert('selesai');
var angka = prompt('masukan angka :');
if (angka % 2 === 0) {
    alert(angka + ' GENAP');
} else {
    alert(angka + ' GANJIL');
}